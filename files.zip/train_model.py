"""Latih model prediksi hujan (jalankan di laptop).
Pakai:  python train_model.py data1.csv data2.csv ...
Butuh:  pip install pandas numpy scikit-learn
Hasil:  rain_model.json  (bobot logistic regression, dibaca HP A tanpa sklearn)

Label: 1 jika ADA hujan dalam 15 menit ke depan, 0 jika tidak.
Sampel saat hujan sedang berlangsung dibuang (yang diprediksi adalah AWAL hujan)."""
import sys, json
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
from features import compute_features, FEATURES, WINDOW_S

HORIZON_S = 15 * 60     # prediksi 15 menit ke depan
STEP_S = 10             # satu sampel latih tiap 10 detik
GAP_TOL = 60            # toleransi data putus di ujung horizon


def build(df):
    df = df.sort_values("ts").reset_index(drop=True)
    ts = df["ts"].values
    M = df[["ts", "lux", "lux_drop", "rms"]].values
    rain = df["rain"].values
    X, y, T = [], [], []
    t = ts[0] + WINDOW_S
    while t <= ts[-1] - HORIZON_S:
        i1 = np.searchsorted(ts, t, side="right")
        i0 = np.searchsorted(ts, t - WINDOW_S, side="left")
        j1 = np.searchsorted(ts, t + HORIZON_S, side="right")
        ok = (rain[i1 - 1] == 0 and ts[i1 - 1] >= t - 5
              and ts[j1 - 1] >= t + HORIZON_S - GAP_TOL)
        if ok:
            feats = compute_features(M[i0:i1].tolist())
            if feats is not None:
                X.append(feats); y.append(int(rain[i1:j1].max())); T.append(t)
        t += STEP_S
    return X, y, T


X, y, T = [], [], []
for path in sys.argv[1:]:
    a, b, c = build(pd.read_csv(path))
    print(f"{path}: {len(a)} sampel, {sum(b)} positif")
    X += a; y += b; T += c

if not X:
    sys.exit("Tidak ada sampel. Pastikan tiap file minimal > 17 menit.")
order = np.argsort(T)
X, y = np.array(X)[order], np.array(y)[order]
if len(set(y)) < 2:
    sys.exit("Data hanya punya 1 kelas. Perlu data hujan DAN tidak hujan.")

# Split berdasarkan waktu (bukan acak) agar tidak bocor antar sampel yang berdekatan
cut = int(len(X) * 0.7)
Xtr, Xte, ytr, yte = X[:cut], X[cut:], y[:cut], y[cut:]

scaler = StandardScaler().fit(Xtr)
clf = LogisticRegression(class_weight="balanced", max_iter=1000)
clf.fit(scaler.transform(Xtr), ytr)

if len(set(yte)) > 1:
    pred = clf.predict(scaler.transform(Xte))
    print("\nEvaluasi pada data uji (30% terakhir secara waktu):")
    print(confusion_matrix(yte, pred))
    print(classification_report(yte, pred, target_names=["aman", "hujan<15mnt"]))
else:
    print("\nPeringatan: data uji hanya 1 kelas, tambah data sebelum percaya hasilnya.")

print("Bobot fitur (setelah standardisasi):")
for n, cf in zip(FEATURES, clf.coef_[0]):
    print(f"  {n:20s} {cf:+.3f}")

json.dump({"features": FEATURES, "mean": scaler.mean_.tolist(),
           "scale": scaler.scale_.tolist(), "coef": clf.coef_[0].tolist(),
           "intercept": float(clf.intercept_[0]),
           "window_s": WINDOW_S, "horizon_s": HORIZON_S},
          open("rain_model.json", "w"), indent=2)
print("\nTersimpan: rain_model.json -> salin ke HP A bersama features.py & rain_model.py")
