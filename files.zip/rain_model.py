"""Inferensi di HP A (Termux). Python murni, tanpa numpy/sklearn."""
import json, math
from features import compute_features


class RainModel:
    def __init__(self, path="rain_model.json"):
        m = json.load(open(path))
        self.mean, self.scale = m["mean"], m["scale"]
        self.coef, self.b = m["coef"], m["intercept"]

    def predict(self, rows):
        """rows: list (ts, lux, lux_drop, rms) dalam 120 detik terakhir.
        Return probabilitas hujan 0..1, atau None jika data belum cukup."""
        f = compute_features(rows)
        if f is None:
            return None
        z = self.b + sum(c * (x - mu) / s
                         for c, x, mu, s in zip(self.coef, f, self.mean, self.scale))
        return 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, z))))
