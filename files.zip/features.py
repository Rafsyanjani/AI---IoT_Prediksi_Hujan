"""Fitur prediksi hujan JemuranGuard.
File ini dipakai SAMA PERSIS saat training (laptop) dan inferensi (Termux),
supaya tidak ada selisih perhitungan antara keduanya."""

FEATURES = ["lux_mean", "lux_slope_per_min", "lux_drop_max",
            "rms_mean", "rms_max", "rms_trend_per_min"]
WINDOW_S = 120      # jendela data terakhir (detik)
MIN_ROWS = 30       # minimal sampel dalam jendela


def _slope(xs, ys):
    """Kemiringan regresi linear sederhana (satuan y per satuan x)."""
    n = len(xs)
    if n < 2:
        return 0.0
    mx, my = sum(xs) / n, sum(ys) / n
    den = sum((x - mx) ** 2 for x in xs)
    if den == 0:
        return 0.0
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den


def compute_features(rows):
    """rows: list of (ts, lux, lux_drop, rms) dalam WINDOW_S terakhir, urut waktu.
    Return list fitur sesuai urutan FEATURES, atau None jika data kurang."""
    if len(rows) < MIN_ROWS:
        return None
    t0 = rows[0][0]
    t = [r[0] - t0 for r in rows]
    lux = [r[1] for r in rows]
    drop = [r[2] for r in rows]
    rms = [r[3] for r in rows]
    n = len(rows)
    return [
        sum(lux) / n,
        _slope(t, lux) * 60,        # lux per menit (negatif = makin gelap)
        max(drop),
        sum(rms) / n,
        max(rms),
        _slope(t, rms) * 60,        # m/s2 per menit (positif = makin kencang)
    ]
