"""Kumpulkan data telemetry + label hujan ke CSV (jalankan di laptop).
Pakai:  python collect_data.py [nama_file.csv]
Saat berjalan, ketik di terminal lalu Enter:
    r = hujan mulai      s = hujan berhenti      q = keluar
Pastikan 'python jemuran.py edge' sedang jalan di HP A."""
import sys, ssl, json, time, csv
import paho.mqtt.client as mqtt

BROKER, PORT = "broker.hivemq.com", 8883
PID = "jemuran_guard_kelompok_07"            # harus sama dengan jemuran.py
TOPIC = f"jemuranguard/{PID}/telemetry"

out = sys.argv[1] if len(sys.argv) > 1 else time.strftime("data_%Y%m%d_%H%M.csv")
state = {"rain": 0, "n": 0}
f = open(out, "w", newline="")
w = csv.writer(f)
w.writerow(["ts", "lux", "lux_drop", "rms", "rain"])


def mk(cid):
    try:
        c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1, client_id=cid)
    except AttributeError:
        c = mqtt.Client(client_id=cid)
    c.tls_set(cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS_CLIENT)
    return c


def on_connect(cl, u, fl, rc, *a):
    cl.subscribe(TOPIC, qos=0)
    print("Terhubung. r=hujan mulai, s=berhenti, q=keluar")


def on_message(cl, u, m):
    try:
        d = json.loads(m.payload.decode())
        w.writerow([d["ts"], d["light_lux"], d["lux_drop"], d["rms_swing"], state["rain"]])
    except (ValueError, KeyError):
        return
    state["n"] += 1
    if state["n"] % 50 == 0:
        f.flush()


c = mk("jg-collector")
c.on_connect, c.on_message = on_connect, on_message
c.connect(BROKER, PORT, 60)
c.loop_start()

try:
    while True:
        cmd = input().strip().lower()
        if cmd == "r":
            state["rain"] = 1; print(">> label: HUJAN")
        elif cmd == "s":
            state["rain"] = 0; print(">> label: TIDAK HUJAN")
        elif cmd == "q":
            break
        else:
            print(f"baris terekam: {state['n']} | rain={state['rain']}")
except (KeyboardInterrupt, EOFError):
    pass
finally:
    c.loop_stop(); f.flush(); f.close()
    print(f"Tersimpan: {out} ({state['n']} baris)")
